<?php
    require "scripts.php";
    session_start();
    $_SESSION["levelsLeft"] = 10;
    head();
?>
<h1>Select your languages</h1>
<form method="get" action="level.php">
    <table class='langselect'>
        <tr class='langselect-title'>
            <td width='50%'><center>Interface</center></td>
            <td width='50%'><center>Words</center></td>
        </tr>
        <?php
            $firstLine  = fgets(fopen("words/words.txt", 'r'));
            $languages = preg_split('/\s+/', $firstLine);
            if (array_shift($languages)) {
                if (array_shift($languages)) {
                    foreach ($languages as $key => $language) {
                        if ($language) {
                            echo "
                            <tr>
                                <td>
                                    <input type='radio' name='interface' id='i".$language."' value='".($key+2)."' class='radio'/>
                                    <label for='i".$language."'>".$language."</label>
                                </td>
                                <td>
                                    <input type='radio' name='vocabulary' id='v".$language."' value='".($key+2)."' class='radio'/>
                                    <label for='v".$language."'>".$language."</label>
                                </td>
                            </tr>
                            ";
                        }
                    }
               }
            }
        ?>
        <tr class='langselect-title'>
            <td width='50%' colspan=2><center>Theme</center></td>
        </tr>
        <?php
            $database = file_get_contents("words/words.txt");
            $entries = preg_split('/\r\n|\r|\n/', $database);
            $i = 0;
            if (array_shift($entries)) {
                foreach ($entries as $theme) {
                    $array = preg_split('/\s+/', $theme);
                    $themes[$i] = $array[1];
                    $i++;
                }
                $themes = array_unique($themes);
            }
            foreach ($themes as $theme) {
                if ($theme) {
                    $transformation = str_replace('_', ' ', $theme);
                    echo "
                    <tr>
                        <td colspan=2>
                            <input type='radio' name='theme' id='".$theme."' value='".$theme."' class='radio'/>
                            <label for='".$theme."'>".ucfirst($transformation)."</label>
                        </td>
                    </tr>
                    ";
                }
            }
        ?>
    </table>
    <a href="index.php" class="btn red">Back</a>
    <input type="submit" class="btn green" value="Play">
</form>
<?php
    foot();
?>