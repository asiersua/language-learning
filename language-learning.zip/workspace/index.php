<?php
    require "scripts.php";
    session_start();
    session_destroy();
    head();
    if ($_GET["state"] == "defeat") {
        echo '<script type="text/javascript">defeat_sound();</script>';
    } else if ($_GET["state"] == "victory") {
        echo '<script type="text/javascript">victory_sound();</script>';
    }
?>
<h1>Learning game</h1>
<a href="languageselect.php" class="btn green">Start</a>
<?php
    foot();
?>