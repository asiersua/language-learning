<?php
    require "scripts.php";
    $seconds = 5;
    session_start();
    if (isset($_POST["right"])) {
        $_SESSION["levelsLeft"]--;
    }
    $conn = connect('localhost', 'anon', '', 'language_learning');
    head();
    if ($_GET["interface"] == $_GET["vocabulary"] || !isset($_GET["interface"]) || !isset($_GET["vocabulary"])) {
        echo "<h1>Please select two different languages!</h1>";
        echo "<a href='languageselect.php' class='btn red'>Go back</a>";
    } else {
        if ($_SESSION["levelsLeft"] == 0 || $_SESSION["fails"] == $seconds-1) {
            if ($_SESSION["levelsLeft"] > 0) {
                header("Location: index.php?state=defeat");
            } else {
                header("Location: index.php?state=victory");
            }
            session_destroy();
        } else {
            $header = "refresh:".(5-$_SESSION["fails"]).";url=level.php?interface=".$_GET["interface"]."&vocabulary=".$_GET["vocabulary"]."&state=timeout";
            header( $header );
        }
        $time = 5000 - (1000 * $_SESSION["fails"]);
        echo '
        <script type="text/javascript">';
        for ($i = 0; $i <= 4; $i++) {
            echo '
            setTimeout(function() {
              document.getElementById("second'.$i.'").style.visibility="hidden";
              second_sound();
            }, '.$time.');
            ';
            $time = $time-1000;
        }
        echo '</script>';
        if (isset($_POST["wrong"]) || $_GET["state"] == "timeout") {
            $_SESSION["fails"]++;
            echo '<script type="text/javascript">wrong_sound();</script>';
        } else if (isset($_POST["right"])) {
            echo '<script type="text/javascript">right_sound();</script>';
        }
        echo "
        <form method='post' action='level.php?interface=".$_GET["interface"]."&vocabulary=".$_GET["vocabulary"]."'>
        <table>
            <tr>";
        for ($i = 0; $i<($seconds-$_SESSION["fails"]); $i++) {
            if ($i >= 3) {
                $class = "green";
            } else if ($i >= 1) {
                $class = "orange";
            } else {
                $class = "red";
            }
            $time = 1000*(5-$i);
            echo '
            <td>
            <div class="btn '.$class.'" id="second'.$i.'">
            </div>
            </td>
            ';
            if (($seconds-$_SESSION["fails"]) < 5 && $i == ($seconds-$_SESSION["fails"]-1)) {
                while ($i < 4) {
                   echo "
                    <td><div class='btn'></div></td>
                    ";
                    $i++;
                }
            }
        }
        $sql = "select max(id) from words";
        $languageQuery = mysqli_query($conn, $sql);
        if ($languageQuery != false) {
            $maxID = mysqli_fetch_array($languageQuery, MYSQLI_NUM);
        }
        $sql = "select min(id) from words";
        $languageQuery = mysqli_query($conn, $sql);
        if ($languageQuery != false) {
            $minID = mysqli_fetch_array($languageQuery, MYSQLI_NUM);
        }
        $randomWord = rand($minID[0], $maxID[0]);
        $playingWord = $randomWord;
        $sql = "select ".$_GET["vocabulary"].", type from words where id=".$playingWord;
        $languageQuery = mysqli_query($conn, $sql);
        if ($languageQuery != false) {
            $word = mysqli_fetch_array($languageQuery, MYSQLI_NUM);
        }
        $type = $word[1];
        echo "
            </tr>
            <tr>
                <td colspan=5><center><a class='btn green' style='width:50%'>".$word[0]."</a></center></td>
            </tr>";
        $sql = "select ".$_GET["interface"]." from words where id=".$playingWord;
        $languageQuery = mysqli_query($conn, $sql);
        if ($languageQuery != false) {
            $word = mysqli_fetch_array($languageQuery, MYSQLI_NUM);
        }
        $options = 2;
        $maxOptions = $options;
        $answers[$options] = $word[0];
        $options--;
        $word[1] = "";
        while ($options >= 0) {
            $sql = "select ".$_GET["interface"].", type from words where id=".$randomWord;
            $languageQuery = mysqli_query($conn, $sql);
            if ($languageQuery != false) {
                $word = mysqli_fetch_array($languageQuery, MYSQLI_NUM);
            }
            while ($word[1] != $type || in_array($word[0], $answers)) {
                $randomWord = rand($minID[0], $maxID[0]);
                $sql = "select ".$_GET["interface"].", type from words where id=".$randomWord;
                $languageQuery = mysqli_query($conn, $sql);
                if ($languageQuery != false) {
                    $word = mysqli_fetch_array($languageQuery, MYSQLI_NUM);
                }
            }
            $answers[$options] = $word[0];
            $options--;
        }
        $filled = 0;
        $filledAnswers[0] = "";
        for ($i = 0; $i <= $maxOptions; $i++) {
            $randomAnswer = $answers[array_rand($answers)];
            while (in_array($randomAnswer, $filledAnswers)) {
                $randomAnswer = $answers[array_rand($answers)];
            }
            $filledAnswers[$filled] = $randomAnswer;
            $filled++;
            if ($randomAnswer == $answers[$maxOptions]) {
                $onclick = 'document.getElementById("'.$randomAnswer.'").className = "btn green";';
                echo "
                <tr>
                    <td colspan=5><center><input type='submit' class='btn blue' style='width:50%' name='right' onclick='".$onclick."' id='".$randomAnswer."' value='".$randomAnswer."'></center></td>
                </tr>
                ";
            } else {
                $onclick = 'document.getElementById("'.$randomAnswer.'").className = "btn red";';
                echo "
                <tr>
                    <td colspan=5><center><input type='submit' class='btn blue' style='width:50%' name='wrong' onclick='".$onclick."' id='".$randomAnswer."' value='".$randomAnswer."'></center></td>
                </tr>
                ";
            }
        }
        echo "
        </table>
        </form>
        ";
    }
    foot();
?>