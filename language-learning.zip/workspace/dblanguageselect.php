<?php
    require "scripts.php";
    session_start();
    $_SESSION["levelsLeft"] = 10;
    $conn = connect('localhost', 'anon', '', 'language_learning');
    head();
?>
<h1>Select your languages</h1>
<form method="get" action="level.php">
    <table class='langselect'>
        <tr class='langselect-title'>
            <td width='50%'><center>Interface</center></td>
            <td width='50%'><center>Words</center></td>
        </tr>
        <?php
            $sql = "show columns from words where field!='id' && field!='type'";
            $languageQuery = mysqli_query($conn, $sql);
            if ($languageQuery != false) {
                $languages = mysqli_fetch_array($languageQuery, MYSQLI_ASSOC);
                while ($languages != null) {
                    echo "
                    <tr>
                        <td>
                            <input type='radio' name='interface' id='i".$languages["Field"]."' value='".$languages["Field"]."' class='radio'/>
                            <label for='i".$languages["Field"]."'>".$languages["Field"]."</label>
                        </td>
                        <td>
                            <input type='radio' name='vocabulary' id='v".$languages["Field"]."' value='".$languages["Field"]."' class='radio'/>
                            <label for='v".$languages["Field"]."'>".$languages["Field"]."</label>
                        </td>
                    </tr>
                    ";
                    $languages = mysqli_fetch_array($languageQuery, MYSQLI_ASSOC);
                }
            }
        ?>
    </table>
    <a href="index.php" class="btn red">Back</a>
    <input type="submit" class="btn green" value="Play">
</form>
<?php
    foot();
?>