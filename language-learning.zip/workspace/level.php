<?php
    require "scripts.php";
    $seconds = 5;
    session_start();
    if (isset($_POST["right"])) {
        $_SESSION["levelsLeft"]--;
    }
    head();
    if ($_GET["interface"] == $_GET["vocabulary"] || !isset($_GET["interface"]) || !isset($_GET["vocabulary"])) {
        echo "<h1>Please select two different languages!</h1>";
        echo "<a href='languageselect.php' class='btn red'>Go back</a>";
    } else {
        if ($_SESSION["levelsLeft"] == 0 || $_SESSION["fails"] >= $seconds-1) {
            if ($_SESSION["levelsLeft"] > 0) {
                if (isset($_POST["wrong"])) {
                    header("Location: index.php?state=defeat");
                }
            } else {
                header("Location: index.php?state=victory");
            }
            session_destroy();
        } else {
            $header = "refresh:".(5-$_SESSION["fails"]).";url=level.php?interface=".$_GET["interface"]."&vocabulary=".$_GET["vocabulary"]."&state=timeout&theme=".$_GET["theme"];
            header( $header );
        }
        $time = 5000 - (1000 * $_SESSION["fails"]);
        echo '
        <script type="text/javascript">';
        for ($i = 0; $i <= 4; $i++) {
            echo '
            setTimeout(function() {
              document.getElementById("second'.$i.'").style.visibility="hidden";
              second_sound();
            }, '.$time.');
            ';
            $time = $time-1000;
        }
        echo '</script>';
        if (isset($_POST["wrong"]) || $_GET["state"] == "timeout") {
            $_SESSION["fails"]++;
            echo '<script type="text/javascript">wrong_sound();</script>';
        } else if (isset($_POST["right"])) {
            echo '<script type="text/javascript">right_sound();</script>';
            unset($_POST["right"]);
        }
        if (isset($_GET["theme"])) {
            echo "
            <form method='post' action='level.php?interface=".$_GET["interface"]."&vocabulary=".$_GET["vocabulary"]."&theme=".$_GET["theme"]."'>
            <table>
                <tr>";
        } else {
            echo "
            <form method='post' action='level.php?interface=".$_GET["interface"]."&vocabulary=".$_GET["vocabulary"]."'>
            <table>
                <tr>";
        }
        for ($i = 0; $i<($seconds-$_SESSION["fails"]); $i++) {
            if ($i >= 3) {
                $class = "green";
            } else if ($i >= 1) {
                $class = "orange";
            } else {
                $class = "red";
            }
            $time = 1000*(5-$i);
            echo '
            <td>
            <div class="btn '.$class.'" id="second'.$i.'">
            </div>
            </td>
            ';
            if (($seconds-$_SESSION["fails"]) < 5 && $i == ($seconds-$_SESSION["fails"]-1)) {
                while ($i < 4) {
                   echo "
                    <td><div class='btn'></div></td>
                    ";
                    $i++;
                }
            }
        }
        $database = file_get_contents("words/words.txt");
        $entries = preg_split('/\r\n|\r|\n/', $database);
        if (array_shift($entries)) {
            if (isset($_GET["theme"])) {
                if ($_SESSION["usedWords"] == null) {
                    $array[] = 0;
                    $_SESSION["usedWords"] = $array;
                }
                do {
                $randomWord = rand(0, count($entries) - 1);
                $zaWord = preg_split('/\s+/', $entries[$randomWord]);
                } while ($zaWord[1] != $_GET["theme"] && in_array($zaWord[1], $_SESSION["usedWords"]));
            } else {
                $randomWord = rand(0, count($entries) - 1);
                $zaWord = preg_split('/\s+/', $entries[$randomWord]);
            }
        }
        $transformation = str_replace('_', ' ', $zaWord[$_GET["vocabulary"]]);
        echo "
            </tr>
            <tr>
                <td colspan=5><center><a class='btn green' style='width:50%'>".$transformation."</a></center></td>
            </tr>";
        $options = 2;
        $maxOptions = $options;
        $answers[$options] = $zaWord[$_GET["interface"]];
        $options--;
        while ($options >= 0) {
            do {
            $randomWord = rand(0, count($entries) - 1);
            $newOption = preg_split('/\s+/', $entries[$randomWord]);
            if (!isset($_GET["theme"])) {
                $newOption[1] = $_GET["theme"];
            }
            } while ($newOption[0] != $zaWord[0] || in_array($newOption[$_GET["interface"]], $answers) || $newOption[1] != $_GET["theme"]);
            $answers[$options] = $newOption[$_GET["interface"]];
            $options--;
        }
        $filled = 0;
        $filledAnswers[0] = "";
        for ($i = 0; $i <= $maxOptions; $i++) {
            do {
                $randomAnswer = $answers[array_rand($answers)];
            } while (in_array($randomAnswer, $filledAnswers));
            $filledAnswers[$filled] = $randomAnswer;
            $filled++;
            $transformation = str_replace('_', ' ', $randomAnswer);
            if ($randomAnswer == $answers[$maxOptions]) {
                $onclick = 'document.getElementById("'.$randomAnswer.'").className = "btn green";';
                echo "
                <tr>
                    <td colspan=5><center><input type='submit' class='btn blue' style='width:50%' name='right' onclick='".$onclick."' id='".$randomAnswer."' value='".$transformation."'></center></td>
                </tr>
                ";
            } else {
                $onclick = 'document.getElementById("'.$randomAnswer.'").className = "btn red";';
                echo "
                <tr>
                    <td colspan=5><center><input type='submit' class='btn blue' style='width:50%' name='wrong' onclick='".$onclick."' id='".$randomAnswer."' value='".$transformation."'></center></td>
                </tr>
                ";
            }
        }
        echo "
        </table>
        </form>
        ";
        $_SESSION["usedWords"][] = $zaWord[$_GET["vocabulary"]];
    }
    foot();
?>