<?php
    function connect($host, $user, $pass, $db){
      return new mysqli($host, $user, $pass, $db);
   }
    function head(){
        echo "
        <head>
    		<meta charset='utf-8'/>
    		<title>Learning Game</title>
    		<link rel='stylesheet' type='text/css' href='style/style.css'/>
    		<script type='text/javascript'>
                function victory_sound() {
                    var audioElement = document.createElement('audio');
                    audioElement.setAttribute('src', 'sfx/victory.wav');
                    audioElement.setAttribute('autoplay', 'autoplay');
                    audioElement.load();
                    audioElement.play();
                }
                function defeat_sound() {
                    var audioElement = document.createElement('audio');
                    audioElement.setAttribute('src', 'sfx/defeat.wav');
                    audioElement.setAttribute('autoplay', 'autoplay');
                    audioElement.load();
                    audioElement.play();
                }
                function right_sound() {
                    var audioElement = document.createElement('audio');
                    audioElement.setAttribute('src', 'sfx/right.wav');
                    audioElement.setAttribute('autoplay', 'autoplay');
                    audioElement.load();
                    audioElement.play();
                }
                function wrong_sound() {
                    var audioElement = document.createElement('audio');
                    audioElement.setAttribute('src', 'sfx/wrong.wav');
                    audioElement.setAttribute('autoplay', 'autoplay');
                    audioElement.load();
                    audioElement.play();
                }
                function second_sound() {
                    var audioElement = document.createElement('audio');
                    audioElement.setAttribute('src', 'sfx/second.wav');
                    audioElement.setAttribute('autoplay', 'autoplay');
                    audioElement.load();
                    audioElement.play();
                }
            </script>
    	</head>
    	<body>
		<div class='wrapper' align='center'>";
	
   }
   function foot(){
        echo "
            <div class='push'></div>
        </div>
		<center>
		<div class='footer'>
			&copy; Asier Suarez 2016
		</div>
		</center>
	</body>
</html>
       ";
   }
?>